import { useEffect, useState, useCallback } from "react";
import dashboardService from "../services/dashboardService";

const initialError = {
  open: false,
  message: "",
};

const useDashboard = () => {
  const [data, setData] = useState(null);
  const [aiData, setAiData] = useState(null);

  const [loading, setLoading] = useState(true);
  const [aiLoading, setAiLoading] = useState(true);

  const [error, setError] = useState(initialError);

  /**
   * Load Dashboard Summary
   */
  const loadSummary = useCallback(async () => {
    try {
      setLoading(true);

      const response = await dashboardService.getSummary();

      setData(response);
    } catch (err) {
      setError({
        open: true,
        message:
          err?.response?.data?.detail ||
          "Không thể tải dữ liệu Dashboard.",
      });
    } finally {
      setLoading(false);
    }
  }, []);

  /**
   * Load AI Insight
   */
  const loadAIInsight = useCallback(async () => {
    try {
      setAiLoading(true);

      const response = await dashboardService.getAIInsight();

      setAiData(response);
    } catch (err) {
      console.error("AI Insight:", err);

      setAiData({
        insight: "Không thể kết nối AI Service.",
      });
    } finally {
      setAiLoading(false);
    }
  }, []);

  /**
   * Reload toàn bộ Dashboard
   */
  const refreshDashboard = useCallback(async () => {
    await Promise.all([
      loadSummary(),
      loadAIInsight(),
    ]);
  }, [loadSummary, loadAIInsight]);

  useEffect(() => {
    refreshDashboard();
  }, [refreshDashboard]);

  const closeError = () => {
    setError(initialError);
  };

  return {
    data,
    aiData,

    loading,
    aiLoading,

    error,

    refreshDashboard,

    closeError,
  };
};

export default useDashboard;