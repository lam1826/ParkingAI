import React from "react";
import {
  Box,
  Grid,
  Snackbar,
  Alert,
} from "@mui/material";

import DashboardHeader from "./components/dashboard/DashboardHeader";
import SummarySection from "./components/dashboard/SummarySection";
import AIInsightCard from "./components/dashboard/AIInsightCard";
import PeakHourCard from "./components/dashboard/PeakHourCard";
import RevenueChart from "./components/dashboard/RevenueChart";
import TrafficChart from "./components/dashboard/TrafficChart";
import useDashboard from "./hooks/useDashboard";

const Dashboard = () => {
  const {
    data,
    aiData,
    loading,
    aiLoading,
    error,
    closeError,
    refreshDashboard,
  } = useDashboard();

  const handleCloseError = (_, reason) => {
    if (reason === "clickaway") return;
    closeError();
  };

  // TODO: Sau này thay bằng API thật
  const revenueChartData = [
    { day: "T2", revenue: 1200000 },
    { day: "T3", revenue: 1800000 },
    { day: "T4", revenue: 2200000 },
    { day: "T5", revenue: 2600000 },
    { day: "T6", revenue: 3200000 },
    { day: "T7", revenue: 4100000 },
    { day: "CN", revenue: 3700000 },
  ];

  const trafficChartData = [
    { hour: "07", count: 15 },
    { hour: "08", count: 35 },
    { hour: "09", count: 52 },
    { hour: "10", count: 46 },
    { hour: "11", count: 30 },
    { hour: "12", count: 22 },
    { hour: "13", count: 18 },
    { hour: "14", count: 40 },
    { hour: "15", count: 55 },
    { hour: "16", count: 61 },
    { hour: "17", count: 70 },
  ];

  return (
    <Box sx={{ p: 3 }}>
      {/* Header */}
      <DashboardHeader
        loading={loading}
        onRefresh={refreshDashboard}
      />

      {/* Summary */}
      <SummarySection
        data={data}
        loading={loading}
      />

      {/* Charts */}
      <Grid
        container
        spacing={3}
        sx={{ mt: 1 }}
      >
        <Grid item xs={12} lg={6}>
          <RevenueChart
            data={revenueChartData}
          />
        </Grid>

        <Grid item xs={12} lg={6}>
          <TrafficChart
            data={trafficChartData}
          />
        </Grid>
      </Grid>

      {/* AI + Peak Hour */}
      <Grid
        container
        spacing={3}
        sx={{ mt: 1 }}
      >
        <Grid item xs={12} lg={6}>
          <AIInsightCard
            loading={aiLoading}
            insight={aiData}
          />
        </Grid>

        <Grid item xs={12} lg={6}>
          <PeakHourCard
            loading={loading}
            data={data?.top_peak_hours ?? []}
          />
        </Grid>
      </Grid>

      {/* Error */}
      <Snackbar
        open={error.open}
        autoHideDuration={6000}
        onClose={handleCloseError}
        anchorOrigin={{
          vertical: "bottom",
          horizontal: "right",
        }}
      >
        <Alert
          severity="error"
          variant="filled"
          onClose={handleCloseError}
          sx={{ width: "100%" }}
        >
          {error.message}
        </Alert>
      </Snackbar>
    </Box>
  );
};

export default Dashboard;